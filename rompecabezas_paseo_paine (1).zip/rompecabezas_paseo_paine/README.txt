Rompecabezas Paseo Paine

Coloca tus imágenes .jpeg en /images con nombres foto_01.jpeg ... foto_10.jpeg.
Coloca tus audios MP3 en /audio con nombres suspense.mp3 y victory.mp3.
